package com.example.bookshelf.ui.theme.screens

import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.bookshelf.data.BookRepo
import com.example.bookshelf.model.Books
import com.example.bookshelf.ui.theme.BookApp
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import retrofit2.HttpException
import java.io.IOException

sealed interface BookUiState {
    data class Success(val books: List<Books>) : BookUiState
    data class Success2(val bookItem: Books) : BookUiState
    object Error : BookUiState
    object Loading : BookUiState
}


/**
 * ViewModel containing the app data and method to retrieve the data
 */
class BookViewModel(private val bookRepository: BookRepo) : ViewModel() {

    var bookUiState: BookUiState by mutableStateOf(BookUiState.Loading)
        private set

    init {
        getBooks(query = "Attack On Titan")

    }

    private val _uiStateSearch = MutableStateFlow(SearchUiState())
    val uiStateSearch = _uiStateSearch.asStateFlow()

    fun getBooks(query : String = "") {
        viewModelScope.launch {
            bookUiState = BookUiState.Loading
            bookUiState = try {
                // Notes: List<Book>? NULLABLE
                val books = bookRepository.getBooks(query)
                if (books == null) {
                    Log.d("BookFetch", "Error: Books are null.")
                    BookUiState.Error
                } else if (books.isEmpty()){
                    Log.d("BookFetch", "Success: Empty book list.")
                    BookUiState.Success(emptyList())
                } else{
                    Log.d("BookFetch", "Success: ${books.size} books fetched.")
                    BookUiState.Success(books)
                }
            } catch (e: IOException) {
                Log.d("BookFetch", "Error: IOException - ${e.message}")
                BookUiState.Error
            } catch (e: HttpException) {
                Log.d("BookFetch", "Error: HttpException - ${e.message}")
                BookUiState.Error
            }
        }
    }

    fun updateQuery(query: String){
        _uiStateSearch.update { currentState ->
            currentState.copy(
                query = query
            )
        }
    }

    fun getBook(id: String) {
        viewModelScope.launch {
            bookUiState = try {
                // Notes: List<Book>? NULLABLE
                val book = bookRepository.getBook(id)
                if (book == null) {
                    BookUiState.Error
                } else{
                    BookUiState.Success2(book)
                }
            } catch (e: IOException) {
                BookUiState.Error
            } catch (e: HttpException) {
                BookUiState.Error
            }
        }
    }

    data class SearchUiState(
        val query: String = ""
    )

    /**
     * Factory for [AmphibiansViewModel] that takes [AmphibiansRepository] as a dependency
     */
    companion object {
        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val application = (this[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY]
                        as BookApp)
                val booksRepository = application.container.bookshelfRepository
                BookViewModel(bookRepository = booksRepository)
            }
        }
    }
}
