package com.example.bookshelf.data

import com.example.bookshelf.model.Books
import com.example.bookshelf.network.BookApiService

interface BookRepo {
    /** Retrieves list of amphibians from underlying data source */
    suspend fun getBooks(query: String): List<Books>?

    suspend fun getBook(id: String): Books?
}

/**
 * Network Implementation of repository that retrieves amphibian data from underlying data source.
 */
