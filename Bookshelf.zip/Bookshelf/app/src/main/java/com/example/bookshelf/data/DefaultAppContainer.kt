package com.example.bookshelf.data

import com.example.bookshelf.network.BookApiService
import com.example.bookshelf.network.BookApiService.Companion.BASE_URL
import com.jakewharton.retrofit2.converter.kotlinx.serialization.asConverterFactory
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.create

class DefaultAppContainer : AppContainer {

    override val bookshelfApiService: BookApiService by lazy {
        Retrofit.Builder()
            .addConverterFactory(GsonConverterFactory.create())
//            .addConverterFactory(json
//                    .asConverterFactory("application/json".toMediaType()))
            .baseUrl(BookApiService.BASE_URL)
            .build()
            .create()
    }

    override val bookshelfRepository: BookRepo by lazy {
        DefaultBookshelfRepository(bookshelfApiService)
    }
}